/*
 * Sample program to show memory layout.
 */

void foo(int a, int b, int c) {
       char buffer1[5];
       char buffer2[10];
}

int main() {
      foo(1,2,3);
      return 0;
}

